const express = require('express');
const router = express.Router();
const User = require('../models/User'); 

// Create a new user
router.post('/saveUser', async (req, res) => {
  try {
    const user = new User(req.body);
    const savedUser = await user.save();
    res.status(201).json(savedUser);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Read all users
router.get('/getAllUser', async (req, res) => {
  try {
    const users = await User.find();
    res.status(200).json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Read a single user by emp_id
router.get('/singleUser/:emp_id', async (req, res) => {
  try {
    const user = await User.findOne({ emp_id: req.params.emp_id });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.status(200).json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update a user by emp_id
router.put('/updateUser/:emp_id', async (req, res) => {
  try {
    const user = await User.findOneAndUpdate(
      { emp_id: req.params.emp_id },
      req.body,
      { new: true, runValidators: true } // Return the updated user and validate the update
    );
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.status(200).json(user);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Delete a user by emp_id
router.delete('/deleteUser/:emp_id', async (req, res) => {
  try {
    const user = await User.findOneAndDelete({ emp_id: req.params.emp_id });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.status(204).send(); // No content
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
