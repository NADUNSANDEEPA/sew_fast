const mongoose = require('mongoose');

const ProductionTeamSchema = new mongoose.Schema({
  team_id: {
    type: String,
    required: true,
    unique: true 
  },
  team_name: {
    type: String,
    required: true
  },
  team_leader: {
    type: String,
    required: true
  },
  team_supervisor: {
    type: String,
    required: true
  },
  team_capacity: {
    type: Number,
    required: true
  },
  timestamp: {
    type: Date,
    default: Date.now 
  }
});

const ProductionTeam = mongoose.model('ProductionTeam', ProductionTeamSchema);
module.exports = ProductionTeam;
