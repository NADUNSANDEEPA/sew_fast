const mongoose = require('mongoose');

const ProductionSchema = new mongoose.Schema({
  team: {
    type: String,
    required: true, 
  },
  hour: {
    type: Number,
    required: true, 
  },
  quality_garment_qty: {
    type: Number,
    required: true, 
  },
  defect_garment_qty: {
    type: Number,
    required: true,
  },
  remake_garment_qty: {
    type: Number,
    required: true, 
  },
  timestamp: {
    type: Date,
    default: Date.now, 
  },
});


const Production = mongoose.model('Production', ProductionSchema);
module.exports = Production;
