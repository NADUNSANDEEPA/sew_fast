const mongoose = require('mongoose');

const DayPlanSchema = new mongoose.Schema({
  plan_id: {
    type: String,
    required: true,
    unique: true 
  },
  date: {
    type: Date,
    required: true
  },
  allocated_production_team: {
    type: String,
    required: true
  },
  style: {
    type: String,
    required: true
  },
  target_garment_quantity: {
    type: Number,
    required: true
  },
  target_efficiency: {
    type: Number,
    required: true
  },
  working_hours: {
    type: Number,
    required: true
  },
  line_workers_count: {
    type: Number,
    required: true
  },
  SMV: {
    type: Number, 
    required: true
  },
  addedUser: {
    type: String, 
    required: true
  },
  TimeStamp: {
    type: Date,
    default: Date.now 
  },
  Status: {
    type: String,
    enum: ['Planned', 'In Progress', 'Completed', 'Cancelled'], 
    default: 'Planned' 
  }
});


const DayPlan = mongoose.model('DayPlan', DayPlanSchema);
module.exports = DayPlan;
